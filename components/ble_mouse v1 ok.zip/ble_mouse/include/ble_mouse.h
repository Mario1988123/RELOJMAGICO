#pragma once

#include "esp_err.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Inicia el dispositivo BLE como ratón HID
esp_err_t ble_mouse_start(const char *device_name);

// Detiene el BLE mouse (opcional)
esp_err_t ble_mouse_stop(void);

// Mueve el ratón relativo (dx, dy) en ejes X/Y
esp_err_t ble_mouse_move(int8_t dx, int8_t dy);

// Click: bit0 = botón izquierdo, bit1 = derecho, bit2 = middle
// Ej: ble_mouse_click(0x01) -> click izquierdo
esp_err_t ble_mouse_click(uint8_t buttons);

// Mantener / soltar botones:
esp_err_t ble_mouse_press(uint8_t buttons);
esp_err_t ble_mouse_release(uint8_t buttons);

#ifdef __cplusplus
}
#endif
