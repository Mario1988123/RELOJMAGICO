#include "ble_mouse.h"

#include <string.h>

#include "esp_log.h"
#include "esp_err.h"

#include "esp_nimble_hci.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_gatts.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

static const char *TAG = "BLE_MOUSE";

static uint16_t hid_service_handle;
static uint16_t hid_input_report_handle;

static uint8_t current_buttons = 0;
static bool ble_mouse_started = false;

static uint8_t mac_addr[6];

// Report descriptor de ratón HID estándar
static const uint8_t hid_report_map[] = {
    0x05, 0x01,       // Usage Page (Generic Desktop)
    0x09, 0x02,       // Usage (Mouse)
    0xA1, 0x01,       // Collection (Application)
    0x09, 0x01,       //   Usage (Pointer)
    0xA1, 0x00,       //   Collection (Physical)
    0x05, 0x09,       //     Usage Page (Buttons)
    0x19, 0x01,       //     Usage Minimum (01)
    0x29, 0x03,       //     Usage Maximum (03)
    0x15, 0x00,       //     Logical Minimum (0)
    0x25, 0x01,       //     Logical Maximum (1)
    0x95, 0x03,       //     Report Count (3)
    0x75, 0x01,       //     Report Size (1)
    0x81, 0x02,       //     Input (Data, Var, Abs) ; botones
    0x95, 0x01,       //     Report Count (1)
    0x75, 0x05,       //     Report Size (5)
    0x81, 0x01,       //     Input (Const, Ary, Abs) ; relleno
    0x05, 0x01,       //     Usage Page (Generic Desktop)
    0x09, 0x30,       //     Usage (X)
    0x09, 0x31,       //     Usage (Y)
    0x15, 0x81,       //     Logical Minimum (-127)
    0x25, 0x7F,       //     Logical Maximum (127)
    0x75, 0x08,       //     Report Size (8)
    0x95, 0x02,       //     Report Count (2)
    0x81, 0x06,       //     Input (Data, Var, Rel) ; ejes X/Y
    0xC0,             //   End Collection
    0xC0              // End Collection
};

// -----------------------------------------------------
// Callbacks GAP/GATT básicos
// -----------------------------------------------------
static int ble_mouse_gap_event(struct ble_gap_event *event, void *arg);

static void ble_mouse_advertise(void)
{
    struct ble_gap_adv_params adv_params;
    memset(&adv_params, 0, sizeof(adv_params));

    adv_params.conn_mode = BLE_GAP_CONN_MODE_UND;
    adv_params.disc_mode = BLE_GAP_DISC_MODE_GEN;

    struct ble_hs_adv_fields fields;
    memset(&fields, 0, sizeof(fields));

    const char *name = ble_svc_gap_device_name();
    fields.name = (uint8_t *)name;
    fields.name_len = strlen(name);
    fields.name_is_complete = 1;

    fields.appearance = 962; // HID mouse
    fields.appearance_is_present = 1;

    int rc = ble_gap_adv_set_fields(&fields);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_gap_adv_set_fields rc=%d", rc);
        return;
    }

    rc = ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC, NULL, BLE_HS_FOREVER,
                           &adv_params, ble_mouse_gap_event, NULL);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_gap_adv_start rc=%d", rc);
    } else {
        ESP_LOGI(TAG, "Advertising HID Mouse as '%s'", name);
    }
}

static int ble_mouse_gap_event(struct ble_gap_event *event, void *arg)
{
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status == 0) {
            ESP_LOGI(TAG, "Client connected");
        } else {
            ESP_LOGW(TAG, "Connect failed; status=%d. Restart adv.", event->connect.status);
            ble_mouse_advertise();
        }
        break;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "Client disconnected; reason=%d", event->disconnect.reason);
        ble_mouse_advertise();
        break;

    case BLE_GAP_EVENT_ADV_COMPLETE:
        ESP_LOGI(TAG, "Advertising complete; restarting");
        ble_mouse_advertise();
        break;

    default:
        break;
    }
    return 0;
}

// -----------------------------------------------------
// GATT: servicio HID muy simplificado
// -----------------------------------------------------

// Característica de entrada de ratón: 3 bytes (buttons, dx, dy)
static const struct ble_gatt_chr_def hid_chrs[] = {
    {
        .uuid = BLE_UUID16_DECLARE(0x2A4D), // Report
        .access_cb = NULL, // Notificado desde el servidor; no lectura especial
        .flags = BLE_GATT_CHR_F_NOTIFY | BLE_GATT_CHR_F_READ,
        .val_handle = &hid_input_report_handle,
    },
    {
        .uuid = BLE_UUID16_DECLARE(0x2A4B), // HID Information
        .access_cb = NULL,
        .flags = BLE_GATT_CHR_F_READ,
    },
    {
        .uuid = BLE_UUID16_DECLARE(0x2A4A), // HID Report Map
        .access_cb = NULL,
        .flags = BLE_GATT_CHR_F_READ,
    },
    {
        0, // terminador
    }
};

static const struct ble_gatt_svc_def gatt_svr_svcs[] = {
    {
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = BLE_UUID16_DECLARE(0x1812), // HID Service
        .characteristics = hid_chrs,
    },
    {
        0, // terminador
    },
};

static void gatt_svr_register_cb(struct ble_gatt_register_ctxt *ctxt, void *arg)
{
    switch (ctxt->op) {
    case BLE_GATT_REGISTER_SVC:
        ESP_LOGI(TAG, "Registered service %s with handle=%d",
                 ble_uuid_to_str(ctxt->svc.svc_def->uuid),
                 ctxt->svc.handle);
        hid_service_handle = ctxt->svc.handle;
        break;

    case BLE_GATT_REGISTER_CHR:
        ESP_LOGI(TAG,
                 "Registered characteristic %s; def_handle=%d val_handle=%d",
                 ble_uuid_to_str(ctxt->chr.chr_def->uuid),
                 ctxt->chr.def_handle,
                 ctxt->chr.val_handle);
        break;

    default:
        break;
    }
}

static int gatt_svr_init(void)
{
    int rc;

    ble_gatts_register_cb(gatt_svr_register_cb, NULL);

    rc = ble_gatts_count_cfg(gatt_svr_svcs);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_gatts_count_cfg rc=%d", rc);
        return rc;
    }

    rc = ble_gatts_add_svcs(gatt_svr_svcs);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_gatts_add_svcs rc=%d", rc);
        return rc;
    }

    return 0;
}

// -----------------------------------------------------
// NimBLE host task
// -----------------------------------------------------

static void ble_host_task(void *param)
{
    ESP_LOGI(TAG, "BLE host task started");
    nimble_port_run();
    nimble_port_freertos_deinit();
}

// -----------------------------------------------------
// API pública
// -----------------------------------------------------

esp_err_t ble_mouse_start(const char *device_name)
{
    if (ble_mouse_started) {
        ESP_LOGW(TAG, "BLE mouse already started");
        return ESP_OK;
    }

    int rc;

    ESP_ERROR_CHECK(esp_nimble_hci_init());

    nimble_port_init();

    ble_hs_cfg.reset_cb = NULL;
    ble_hs_cfg.sync_cb = NULL;
    ble_hs_cfg.gap_event_cb = ble_mouse_gap_event;

    rc = gatt_svr_init();
    if (rc != 0) {
        ESP_LOGE(TAG, "gatt_svr_init failed: %d", rc);
        return ESP_FAIL;
    }

    // Nombre del dispositivo
    ble_svc_gap_init();
    ble_svc_gatt_init();

    if (device_name == NULL) {
        device_name = "S3Mouse";
    }
    rc = ble_svc_gap_device_name_set(device_name);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_svc_gap_device_name_set rc=%d", rc);
    }

    // Dirección pública (se suele usar la por defecto)
    rc = ble_hs_id_infer_auto(0, &mac_addr[0]);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_hs_id_infer_auto rc=%d", rc);
        return ESP_FAIL;
    }

    nimble_port_freertos_init(ble_host_task);

    // Una vez que el host está listo, arrancará callback de sync; aquí lo hacemos simple:
    // Lanzamos advertising después de un pequeño delay (para asegurar que ble_hs está listo)
    vTaskDelay(pdMS_TO_TICKS(500));
    ble_mouse_advertise();

    ble_mouse_started = true;
    ESP_LOGI(TAG, "BLE Mouse started");
    return ESP_OK;
}

esp_err_t ble_mouse_stop(void)
{
    if (!ble_mouse_started)
        return ESP_OK;

    ble_mouse_started = false;

    ble_gap_adv_stop();
    nimble_port_stop();
    esp_nimble_hci_and_controller_deinit();

    ESP_LOGI(TAG, "BLE Mouse stopped");
    return ESP_OK;
}

static esp_err_t ble_mouse_send_report(uint8_t buttons, int8_t dx, int8_t dy)
{
    if (!ble_mouse_started) {
        return ESP_ERR_INVALID_STATE;
    }

    uint8_t report[3];
    report[0] = buttons;
    report[1] = (uint8_t)dx;
    report[2] = (uint8_t)dy;

    int rc = ble_gatts_notify_flat(
        BLE_HS_CONN_HANDLE_NONE, // notificar a todos los conectados
        hid_input_report_handle,
        report,
        sizeof(report)
    );

    if (rc != 0) {
        ESP_LOGE(TAG, "ble_gatts_notify_flat rc=%d", rc);
        return ESP_FAIL;
    }

    return ESP_OK;
}

esp_err_t ble_mouse_move(int8_t dx, int8_t dy)
{
    return ble_mouse_send_report(current_buttons, dx, dy);
}

esp_err_t ble_mouse_click(uint8_t buttons)
{
    esp_err_t err;

    // Presiona
    err = ble_mouse_send_report(buttons, 0, 0);
    if (err != ESP_OK) return err;

    vTaskDelay(pdMS_TO_TICKS(10));

    // Suelta
    err = ble_mouse_send_report(0x00, 0, 0);
    return err;
}

esp_err_t ble_mouse_press(uint8_t buttons)
{
    current_buttons |= buttons;
    return ble_mouse_send_report(current_buttons, 0, 0);
}

esp_err_t ble_mouse_release(uint8_t buttons)
{
    current_buttons &= ~buttons;
    return ble_mouse_send_report(current_buttons, 0, 0);
}
